#ifndef VERSION_H
#define VERSION_H
const QString PROGRAM_VERSION="1.1.14";
#endif

